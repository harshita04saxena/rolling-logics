import java.io.File;
import java.io.IOException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.ObjectMapper;

public class TestPostApi {

	CloseableHttpClient httpClient = HttpClients.createDefault();
	String mainURL = "https://reqres.in/";
	String serviceURL = "/api/users";
	String finalURI = mainURL + serviceURL;
	
	public CloseableHttpResponse post(String url, String entityBody)
			throws ClientProtocolException, IOException, Exception {

		CloseableHttpClient httpClient = HttpClients.createDefault();
		HttpPost httppost = new HttpPost(url);
		httppost.setEntity(new StringEntity(entityBody));

		CloseableHttpResponse closeableHttpResponse = httpClient.execute(httppost);
		return closeableHttpResponse;

	}

	@Test
	public void postApiMethod() throws ClientProtocolException, IOException, Exception {
		TestPostApi obj = new TestPostApi();
		StatusCode sc = new StatusCode();

		ObjectMapper mapper = new ObjectMapper(); // used ObjectMapper class of jackson API
		UserClass user = new UserClass("morpheus", "leader"); // given the name and job-- api body

		// Convert the object to json
		mapper.writeValue(new File("../TestProj/src/main/java/com/qa/data/users.json"), user);

		// convert the json to string
		String APIBody = mapper.writeValueAsString(user);

		CloseableHttpResponse closeableHttpResponse;
		closeableHttpResponse = obj.post(finalURI, APIBody);
		int statuscode = closeableHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statuscode, sc.RESPONSE_STATUS_CODE_201);

	}

}
