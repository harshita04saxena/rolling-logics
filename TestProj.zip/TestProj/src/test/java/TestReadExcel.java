import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TestReadExcel {

	public String getCellData(String sheetname, String colName, int rowNum) {

		FileInputStream fis = null;
		try {
			fis = new FileInputStream("../TestProj/src/main/java/com/qa/data/Test.xlsx");
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
		XSSFWorkbook wb =null;
		try {
			wb = new XSSFWorkbook(fis);
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		int colNum = -1;
		XSSFSheet sheet = wb.getSheet(sheetname);

		Row row = sheet.getRow(0);
		Cell cell = null;

		for (int i = 0; i < row.getLastCellNum(); i++) {
			if (row.getCell(i).getStringCellValue().trim().equals(colName))
				colNum = i;
		}

		row = sheet.getRow(rowNum);
		cell = row.getCell(colNum);

		return cell.getStringCellValue();

	}

	public static void main(String[] args) {

		TestReadExcel excel = new TestReadExcel();

		try {
			System.out.println(excel.getCellData("Sheet1", "name", 1));
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			System.out.println(excel.getCellData("Sheet1", "job", 1));
		} catch (Exception e) {

			e.printStackTrace();
		}

	}

}
