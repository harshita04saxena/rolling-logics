
public class UserClass {

	String name;
	String job;
	String id;
	String createdAt;
	
	
	public UserClass() {
		
	}
	
	public UserClass(String name, String job)
	{
		this.name = name;
		this.job = job;
		
	}
	
	//getters and setters
	
	public String getName() {
		return name;
	}
	
	public String setName(String name) {
		return name;
	}
	
	public String getJob() {
		return job;
	}
	
	public String setJob(String job) {
		return job;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}
	
	
	
	
	
}




